INSERT INTO EMPLOYEE (id, modificationCounter, employeeid, name, surname,email) VALUES
(1, 1, 1, 'Stefano','Rossini','stefano.rossini@capgemini.com');
INSERT INTO EMPLOYEE (id, modificationCounter, employeeid, name, surname,email) VALUES
(2, 2, 2, 'Angelo','Muresu', 'angelo.muresu@capgemini.com');
INSERT INTO EMPLOYEE (id, modificationCounter, employeeid, name, surname,email) VALUES
(3, 3, 3, 'Jaime','Gonzalez', 'jaime.diaz-gonzalez@capgemini.com');