package com.devonfw.application.employee.employeemanagement.service.impl.kafka;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.LoggerFactory;

import com.devonfw.application.employee.employeemanagement.logic.api.Employeemanagement;
import com.devonfw.module.kafka.common.messaging.retry.api.client.MessageProcessor;

import ch.qos.logback.classic.Logger;

/**
 * This is an implementation class for {@link MessageProcessor}. Here in this sample application the consumed message
 * from {@link DeleteEmployeeMessageConsumer} is used as an information for
 * {@link Employeemanagement#deleteEmployee(long)} to delete an employee already exists in the DB.
 *
 * @param <K> the key type.
 * @param <V> the value type.
 *
 */
@Named
public class DeleteEmployeeMessageProcessor<K, V> implements MessageProcessor<K, V> {

  private static final Logger LOG = (Logger) LoggerFactory.getLogger(DeleteEmployeeMessageProcessor.class);

  @Inject
  private Employeemanagement employeemanagement;

  @Override
  public void processMessage(ConsumerRecord<K, V> message) {

    long employeeId = 0L;
    try {
      employeeId = Long.parseLong(message.value().toString());
    } catch (Exception e) {
      LOG.warn("Message conversion failed and it will be ignored", e);
    }

    this.employeemanagement.deleteEmployee(employeeId);
  }

}
